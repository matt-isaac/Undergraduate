Main start method is in View.java
(To run program, run View.java)