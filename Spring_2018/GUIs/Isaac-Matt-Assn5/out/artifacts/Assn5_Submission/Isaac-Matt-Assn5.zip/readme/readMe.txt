Main start method is in Paint class.
Screenshot is in data folder.